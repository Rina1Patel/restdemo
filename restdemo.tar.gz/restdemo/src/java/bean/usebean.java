/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

/**
 *
 * @author mtech
 */
public class usebean {

    int id;
    String masterk;
    String valkcol;

    public int getId() {
        return id;
    }

    public String getMasterk() {
        return masterk;
    }

    public String getValkcol() {
        return valkcol;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setMasterk(String masterk) {
        this.masterk = masterk;
    }

    public void setValkcol(String valkcol) {
        this.valkcol = valkcol;
    }

}
