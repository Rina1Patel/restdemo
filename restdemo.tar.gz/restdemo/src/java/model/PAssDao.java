/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import bean.UserPass;
import bean.usebean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import util.DBconnection;

/**
 *
 * @author mtech
 */
public class PAssDao {

    Connection con;
    PreparedStatement pt = null;
    ResultSet rs = null;
    Statement st = null;

    public int validate(UserPass u) {
        int i = 0;
        try {

            con = DBconnection.getConnection();
            pt = con.prepareStatement("SELECT * FROM mycomp.user_pass where username=? and password=?;");
            pt.setString(1, u.getUser());
            pt.setString(2, u.getPass());
            rs = pt.executeQuery();
            if (rs.next()) {
                System.out.println(" " + rs.getString("id") + " " + rs.getString("password"));
                i = 1;
            } else {
                System.out.println("fdfhtg ");
                i = 0;
            }

        } catch (Exception e) {
            // TODO: handle exception
        }
        return i;
    }

    public int insertUser(UserPass u) {
        int i = 0;
        try {
            //System.out.println("fjdfjsbfhsb");
            con = DBconnection.getConnection();

            pt = (PreparedStatement) con.prepareStatement("insert into user_pass(username,password) values(?,?)");
            pt.setString(1, u.getUser());
            pt.setString(2, u.getPass());
            // pt.setInt(3, user.getId());
            i = pt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        return i;
    }

}
