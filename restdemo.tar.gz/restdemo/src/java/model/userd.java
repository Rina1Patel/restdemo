/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import bean.usebean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import util.DBconnection;

/**
 *
 * @author mtech
 */
public class userd {

    Connection con;
    PreparedStatement pt = null;
    ResultSet rs = null;
    Statement st = null;

    public ArrayList<usebean> showUser(int start, int total) {
        ArrayList<usebean> a1 = new ArrayList();
        try {
            int i = 0;
            String s = "y";
            con = DBconnection.getConnection();
            pt = con.prepareStatement("select  * from valk limit " + (start - 1) + "," + total);
            // pt.setString(1,s);
            rs = pt.executeQuery();
            while (rs.next()) {
                usebean u = new usebean();

                u.setId(rs.getInt("id"));
                u.setMasterk(rs.getString("masterk"));
                u.setValkcol(rs.getString("valkcol"));
                a1.add(u);
            }

        } catch (Exception e) {
            // TODO: handle exception
        }
        return a1;
    }

    public int show() {

        int i = 0;
        try {

            con = DBconnection.getConnection();
            pt = con.prepareStatement("select  * from valk");
            // pt.setString(1,s);
            rs = pt.executeQuery();
            while (rs.next()) {
                i++;
            }

        } catch (Exception e) {
            // TODO: handle exception
        }
        return i;
    }

}
