
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class clientdemo extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            URL url = null;
            if (Integer.parseInt(request.getParameter("flag")) == 1) {
                int id = Integer.parseInt(request.getParameter("id"));

                url = new URL("http://localhost:17733/RestTodo/webresources/v2/generic/" + id);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output = br.readLine();
                out.println("Output from Server .... \n");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(output);
                JSONArray lang = (JSONArray) jsonObject.get("add_data");
                Iterator i = lang.iterator();
                out.println("<table style=\"width:50%\">");
                out.println("<tr>");
                out.println("<th>key</th>");
                out.println("<th>value</th>");

                out.println("</tr>");
                while (i.hasNext()) {
                    JSONObject innerObj = (JSONObject) i.next();
                    if (innerObj == null) {
                        out.print("not available");
                        break;
                    }
                    out.println("<tr><td>" + innerObj.get("key") + "</td>");
                    out.println("<td>" + innerObj.get("value") + "</td></tr>");
                     out.println("<br><a href='webservice client.jsp'>home</a>");
                
                }
                conn.disconnect();
            } else {

                url = new URL("http://localhost:17733/RestTodo/webresources/v2/generic");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                //conn.setRequestProperty("version","1");

                if (conn.getResponseCode() != 200) {
                    throw new RuntimeException("Failed : HTTP error code : "
                            + conn.getResponseCode());
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(
                        (conn.getInputStream())));

                String output = br.readLine();
                out.println("Output from Server .... \n");

                JSONParser jsonParser = new JSONParser();
                JSONObject jsonObject = (JSONObject) jsonParser.parse(output);
                JSONArray lang = (JSONArray) jsonObject.get("add_data");
                /* Iterator i = lang.iterator();
                while (i.hasNext()) {
                    JSONObject innerObj = (JSONObject) i.next();
                    if (innerObj == null) {
                        out.print("not available");
                        break;
                    }
                    out.println("key" + innerObj.get("key")
                            + " value " + innerObj.get("value"));
                    System.out.println("key" + innerObj.get("key")
                            + " value " + innerObj.get("value"));
                }*/
                out.println("<table style=\"width:50%\">");
                out.println("<tr>");
                out.println("<th>key</th>");
                out.println("<th>value</th>");

                out.println("</tr>");

                for (int i = 0; i < lang.size(); i++) {
                    //Store the JSON objects in an array
                    //Get the index of the JSON object and print the values as per the index
                    JSONObject jsonobj_1 = (JSONObject) lang.get(i);
                    //Store the JSON object in JSON array as objects (For level 2 array element i.e Address Components)
                    //JSONArray jsonarr_2 = (JSONArray) jsonobj_1.get("address_components");

                    out.println("<tr><td>" + jsonobj_1.get("key") + "</td>");
                    out.println("<td>" + jsonobj_1.get("value") + "</td></tr>");

                }
                out.println("</table>");
                 out.println("<br><a href='webservice client.jsp'>home</a>");
                conn.disconnect();
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(clientdemo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(clientdemo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
