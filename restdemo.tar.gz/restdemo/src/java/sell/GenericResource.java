/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sell;

import bean.UserPass;
import bean.usebean;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sun.mail.iap.Response;
import com.sun.tools.ws.wsdl.document.jaxws.Exception;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import static javax.ws.rs.core.Response.ok;
import model.PAssDao;
import model.userdao;
import sun.util.locale.StringTokenIterator;

/**
 * REST Web Service
 *
 * @author mtech
 */
@Path("v1/generic")
public class GenericResource {

    @Context
    private UriInfo context;

    public GenericResource() {
    }

    private int authenticate(String user, String pass) {

        UserPass u = new UserPass();
        u.setPass(pass);
        u.setUser(user);
        PAssDao d = new PAssDao();
        int j = d.validate(u);
        if (j != 1) {
            return 0;
        } else {
            return 1;
        }
    }

    @PUT
    @Path("reg")
    @Produces(MediaType.APPLICATION_JSON)
    public String getJsonput(@HeaderParam("user") String str, @HeaderParam("pass") String pass) {

//        JsonArray data_json = new JsonArray();
//        JsonObject res = new JsonObject();
//        UserPass u = new UserPass();
//        u.setPass(pass);
//        u.setUser(str);
//        PAssDao d = new PAssDao();
//        int i = d.insertUser(u);
//        if (i == 1) {
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", "now u can use http methods of this resource");
//            data_json.add(json1);
//            res.add("add_data", data_json);
//            return res.toString();
//        } else {
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", "already exist username");
//            data_json.add(json1);
//            res.add("add_data", data_json);
//            return res.toString();
//        }
JsonArray data_json = new JsonArray();
        JsonObject res = new JsonObject();
    JsonObject json1 = new JsonObject();
            json1.addProperty("key", "use updated version");
            data_json.add(json1);
            res.add("add_data", data_json);
            return res.toString();
    }

    @GET

    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
         JsonArray data_json = new JsonArray();
        JsonObject res = new JsonObject();

//        JsonArray data_json = new JsonArray();
//        JsonObject res = new JsonObject();
////TODO return proper representation object
//
//        ArrayList<usebean> a1 = new ArrayList();
//        userdao uv = new userdao();
//        a1 = uv.showUser();
//        int i = 0;
//        while (i < a1.size()) {
//            JsonObject json = new JsonObject();
//            json.addProperty("key", a1.get(i).getMasterk());
//            json.addProperty("value", a1.get(i).getValkcol());
//            data_json.add(json);
//            i++;
//
//        }
//
//        res.add("add_data", data_json);
//
//        //out.println(ar.get(1).getSubcat_name())
//         return res.toString();
 JsonObject json1 = new JsonObject();
            json1.addProperty("key", "use updated version");
            data_json.add(json1);
            res.add("add_data", data_json);
            return res.toString();
   
    }

    @GET
    @Path("{d}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson(@PathParam("d") Integer id) {
        //TODO return proper representation object

//        JsonArray data_json = new JsonArray();
//        JsonObject res = new JsonObject();
//        userdao uv = new userdao();
//        usebean u = uv.showUser(id);
//        JsonObject json = new JsonObject();
//        if (u != null) {
//
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", u.getMasterk());
//            json1.addProperty("value", u.getValkcol());
//            data_json.add(json1);
//            res.add("add_data", data_json);
//            return res.toString();
//        } else {
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", "data not available");
//            data_json.add(json1);
//            res.add("add_data", data_json);
//            return res.toString();
//
//        }
JsonArray data_json = new JsonArray();
        JsonObject res = new JsonObject();
    JsonObject json1 = new JsonObject();
            json1.addProperty("key", "use updated version");
            data_json.add(json1);
            res.add("add_data", data_json);
            return res.toString();
    }

    @PUT
    // @Path("{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    public String putJson(@HeaderParam("user") String str, @HeaderParam("pass") String pass, @HeaderParam("insert") String insert) {
        //  ="ror!patel";
//        int j = authenticate(str, pass);
//        if (j != 1) {
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", "not authinticated");
//            // return Response.OK;
//            return json1.toString();
//        }
//        StringTokenizer st = new StringTokenizer(insert.toString(), "!");
//        String s = st.nextToken();
//        String v = st.nextToken();
//        usebean u1 = new usebean();
//        u1.setMasterk(s);
//
//        u1.setValkcol(v);
//        userdao d1 = new userdao();
//        int i = d1.insertUser(u1);
//        if (i == 1) {
//            return "inserted";
//        } else {
//            return "record exists or input not formated";
//        }
JsonArray data_json = new JsonArray();
        JsonObject res = new JsonObject();
    JsonObject json1 = new JsonObject();
            json1.addProperty("key", "use updated version");
            data_json.add(json1);
            res.add("add_data", data_json);
            return res.toString();
    }

    @GET
    @Path("delete/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson1(@HeaderParam("user") String str, @HeaderParam("pass") String pass, @PathParam("id") Integer id) {
        //TODO return proper representation object

//        int j = authenticate(str, pass);
//        if (j != 1) {
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", "not authinticated");
//            // return Response.OK;
//            return json1.toString();
//        }
//        userdao d1 = new userdao();
//        int i = d1.deleteUser(id);
//        if (i == 1) {
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", "deleted");
//            //return Response.OK;
//            return json1.toString();
//        } else {
//            JsonObject json1 = new JsonObject();
//            json1.addProperty("key", "data not available which u want to delete");
//            //return Response.OK;
//            return json1.toString();
//        }
JsonArray data_json = new JsonArray();
        JsonObject res = new JsonObject();
    JsonObject json1 = new JsonObject();
            json1.addProperty("key", "use updated version");
            data_json.add(json1);
            res.add("add_data", data_json);
            return res.toString();

    }

    @POST

    @Produces(MediaType.TEXT_PLAIN)
    public String putJson1(@FormParam("id") Integer id, @FormParam("key") String key, @FormParam("value") String value) {
//        usebean u = new usebean();
//        u.setMasterk(key);
//        u.setId(id);
//        u.setValkcol(value);
//        userdao d = new userdao();
//        int i = d.updateUser(u);
//        if (i == 1) {
//
//            return "updated";
//        } else {
//            return "record exists or input not formated";
//        }
JsonArray data_json = new JsonArray();
        JsonObject res = new JsonObject();
    JsonObject json1 = new JsonObject();
            json1.addProperty("key", "use updated version");
            data_json.add(json1);
            res.add("add_data", data_json);
            return res.toString();
    }

}
