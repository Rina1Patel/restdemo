/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author mtech
 */
public class DBconnection {
    static Connection con;
	static String url="jdbc:mysql://localhost:3306/mycomp";
	static String user="root";
	static String password="root";
	static String classname="com.mysql.jdbc.Driver";
	public static Connection getConnection() {
		
		try {
			Class.forName(classname);
			con=DriverManager.getConnection(url,user,password);
			
			if(con!=null){
				System.out.println("connected");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		
		}
		return con;
	}
    
}
