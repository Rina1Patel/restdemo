
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import util.DBconnection;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mtech
 */
public class NewClass {
    public static void main(String[] args) {
        int i=0;
		try {
			System.out.println("update");
            Connection con = DBconnection.getConnection();

            String key="p";
String value="z";
            PreparedStatement pt = con.prepareStatement("update kv set key=?,value=? where id=?;");
			
			pt.setString(1, key);
			pt.setString(2, value);
			pt.setInt(3,8);
			
			i=pt.executeUpdate();
			      /*pt=con.prepareStatement("update kv set key=?,value=? where id=?");
			
			pt.setString(1, user.getKey());
			pt.setString(2, user.getValue());
			pt.setInt(3,user.getId());
			*/
//pt.setInt(3,user.getId());
			                 //System.out.println(" "+user.getKey()+" "+user.getId()+" "+user.get);
		//i=pt.executeUpdate();
			                
			
		} catch (Exception e) {
			                 System.out.println(e);
		}
    }
}
