/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import bean.usebean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import util.DBconnection;

/**
 *
 * @author mtech
 */
public class userdao {

    Connection con;
    PreparedStatement pt = null;
    ResultSet rs = null;
    Statement st = null;

    public int insertUser(usebean user) {
        int i = 0;
        try {
            System.out.println("fjdfjsbfhsb");
            con = DBconnection.getConnection();
            /*	pt=(PreparedStatement) con.prepareStatement("insert into kv('key','value') values(?,?)");
			 	pt.setString(1, user.getKey());
			 	pt.setString(2,user.getValue());
			 
			 	i=pt.executeUpdate();
             */
            pt = (PreparedStatement) con.prepareStatement("insert into valk(masterk,valkcol) values(?,?)");
            // 	pt.setInt(1,9);
            pt.setString(1, user.getMasterk());
            pt.setString(2, user.getValkcol());

            i = pt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        return i;
    }

    public ArrayList<usebean> showUser() {
        ArrayList<usebean> a1 = new ArrayList();
        try {
            int i = 0;
            String s = "y";
            con = DBconnection.getConnection();
            pt = con.prepareStatement("select * from valk");
            // pt.setString(1,s);
            rs = pt.executeQuery();
            while (rs.next()) {
                usebean u = new usebean();

                u.setId(rs.getInt("id"));
                u.setMasterk(rs.getString("masterk"));
                u.setValkcol(rs.getString("valkcol"));
                a1.add(u);
            }

        } catch (Exception e) {
            // TODO: handle exception
        }
        return a1;
    }

    public int updateUser(usebean user) {

        int i = 0;
        try {
            System.out.println("update");
            con = DBconnection.getConnection();

            String str = "update valk set masterk='" + user.getMasterk() + "',valkcol='" + user.getValkcol() + "' where id=" + user.getId() + "";
            st = con.createStatement();
            /*pt=con.prepareStatement("update kv set key=?,value=? where id=?");
			
			pt.setString(1, user.getKey());
			pt.setString(2, user.getValue());
			pt.setInt(3,user.getId());
             */
//pt.setInt(3,user.getId());
            //System.out.println(" "+user.getKey()+" "+user.getId()+" "+user.get);
            i = st.executeUpdate(str);

        } catch (Exception e) {
            // TODO: handle exception
        }
        return i;
    }

    public int deleteUser(int id) {
        int i = 0;

        try {
            con = DBconnection.getConnection();
            pt = con.prepareStatement("delete from valk where id=?");

            pt.setInt(1, id);
            i = pt.executeUpdate();

        } catch (Exception e) {
            // TODO: handle exception
        }
        return i;

    }

}
