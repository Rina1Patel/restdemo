/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sell;

import bean.usebean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.core.MediaType;
import util.DBconnection;

/**
 * REST Web Service
 *
 * @author mtech
 */
@Path("generic")
public class GenericResource {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of GenericResource
     */
    public GenericResource() {
    }

    /**
     * Retrieves representation of an instance of sell.GenericResource
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String getHtml() {
        //TODO return proper representation object
        Connection con;
        PreparedStatement pt = null;
        ResultSet rs = null;
        Statement st = null;
        String r = null;
        //  ArrayList<usebean> a1=new ArrayList();
        try {
            int i = 0;
            String s = "y";
            con = DBconnection.getConnection();
            pt = con.prepareStatement("select * from valk");
            // pt.setString(1,s);
            rs = pt.executeQuery();
            rs.next();
            r = rs.getString("id") + " " + rs.getString("masterk");

        } catch (Exception e) {
            // TODO: handle exception
        }
        return r;
    }

    /**
     * PUT method for updating or creating an instance of GenericResource
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.TEXT_HTML)
    public void putHtml(String content) {
    }
}
