
import java.util.Date;
import java.util.Scanner;
import java.util.StringTokenizer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mtech
 */
public class tue {

    public void get() {
        int a[] = new int[15];
        int i = 0, k;
        Date d = new Date();
        StringTokenizer st = new StringTokenizer(d.toString(), " ");
        String s = st.nextToken();

        if (s.equals("Tue")) {
            //k=d.getDate();
            k = d.getDate() + 4;
            int m = k;
            int p = k;
            // System.out.println(" "+p);
            while (p >= 1) {

                if (p - 7 < 0) {
                    break;
                }
                a[i] = p - 7;
                a[++i] = p - 6;
                p = p - 7;
                i++;
            }

            while (k <= 31) {

                a[i] = k;

                k = k + 7;
                i++;
            }
            while (m <= 30) {
                a[i] = m + 1;
                i++;
                m = m + 7;

            }

        }
        Scanner sc = new Scanner(System.in);
        System.out.println(" how many holidays");
        int holiday = sc.nextInt();
        System.out.println("enter holidays date");
        for (int g = 0; g < holiday; g++) {
            a[i] = sc.nextInt();
            i++;
        }

        for (int m = 0; m < i; m++) {
            for (int g = m; g < i; g++) {
                if (a[m] > a[g]) {
                    int temp = a[m];
                    a[m] = a[g];
                    a[g] = temp;
                }
            }
        }
        System.out.println("total holidays");
        int y = 0;
        System.out.println("total holidays");
        for (y = 0; y < i; y++) {
            System.out.println(" " + a[y]);
        }
        System.out.println("enter day you want to find working day");

        int work = sc.nextInt();
        int flag = 0;
        for (int j = 0; j < i; j++) {

            if (flag == 1) {
                break;
            }
            if (work == a[j]) {
                int x = j;
                int l = 0;
                while (a[x + 1] - a[x] == 1) {
                    l++;

                    x++;
                }

                if (l != 0) {
                    flag = 1;
                    System.out.println("working day " + (a[x] + 1));
                } else {
                    flag = 1;
                    System.out.println("working day  " + (a[j] + 1));
                }

            } else if (work < a[0]) {
                int g = j;
                int n = 0;
                int m = 0;
                if (work + 1 == a[j]) {
                    m = 1;
                    while (a[g + 1] - a[g] == 1) {
                        n++;
                        //   System.out.println("hello");
                        g++;
                    }
                }
                if (n != 0) {
                    flag = 1;
                    System.out.println("working day  " + (a[g] + 1));

                } else if (m == 1) {
                    flag = 1;
                    System.out.println("working day " + (a[j] + 1));

                } else {

                    flag = 1;
                    System.out.println("working day=" + (work + 1));
                }
            } else if (a[j] < work && a[j + 1] > work) {
                int x = j;
                int l = 0;
                int temp = work;
                while (a[x + 1] - temp == 1) {
                    l++;
                    temp = a[x + 1];
                    x++;

                }

                if (l != 0) {
                    flag = 1;
                    System.out.println("working day " + (a[x] + 1));
                } else {
                    flag = 1;
                    System.out.println("working day  " + (work + 1));
                }

            } else if (work > a[y - 1] && work < 31) {
                flag = 1;
                System.out.println("working day  " + (work + 1));

            }
        }

    }

}
