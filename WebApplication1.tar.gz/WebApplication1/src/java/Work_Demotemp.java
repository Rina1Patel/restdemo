
import java.util.Date;
import java.util.StringTokenizer;

public class Work_Demotemp {

    public static void main(String[] args) {
        Date d = new Date();
        StringTokenizer st = new StringTokenizer(d.toString(), " ");
        String s = st.nextToken();
        System.out.println(" " + s);
        System.out.println(" " + d.toString());
        if (s.equals("Wed")) {
            wed w = new wed();
            w.get();
        } else if (s.equals("Mon")) {
            mon m = new mon();
            m.get();
        } else if (s.equals("Tue")) {
            tue t = new tue();
            t.get();
        } else if (s.equals("Thu")) {
            thu t = new thu();
            t.get();
        } else if (s.equals("Fri")) {
            fri f = new fri();
            f.get();
        } else if (s.equals("Sat")) {
            sat s1;
            s1 = new sat();
            s1.get();
        } else {
            sun s2 = new sun();
            s2.get();
        }
    }
}
