
import com.opencsv.CSVReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class csvfile {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        String csvFilename = "/home/mtech/temp.csv";
        CSVReader csvReader = new CSVReader(new FileReader(csvFilename));
        String[] row = null;

        while ((row = csvReader.readNext()) != null) {

            System.out.println(row[1]);
            System.out.println("json responce->");
            System.out.println(getresponce(row[1]));
        }

        csvReader.close();

    }

    public static String getresponce(String uri) throws FileNotFoundException, IOException {
        String csvFilename2 = "/home/mtech/json_res.csv";
        CSVReader csvReader2 = new CSVReader(new FileReader(csvFilename2));
        String[] row2 = null;
        String s = null;
        while ((row2 = csvReader2.readNext()) != null) {
            if (row2[0].equals(uri)) {
                s = row2[1];
                break;
            }

        }
        csvReader2.close();
        return s;
    }
}
